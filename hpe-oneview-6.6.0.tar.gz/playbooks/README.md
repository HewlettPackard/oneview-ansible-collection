#  Managing FC Network modules

This example describes how to use Ansible to manage FC Network resources

## Create a simple Ansible playbook

**Step 1**
Create a playbook called  `oneview_fc_network.yaml`.

**Step 2**
Run the playbook.

`ansible-playbook oneview_fc_network.yaml`
